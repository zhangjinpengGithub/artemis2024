import pandas as pd
import os,sys
from pathlib import Path

# 设置文件路径
denovo_kmer_type_path = "./denovo_kmer_type"
####unique_kmer_type_path = "./unique_kmer_type"
unique_kmer_type_path = "./test"
# 获取所有满足条件的文件
files = [f for f in os.listdir(denovo_kmer_type_path) if f.endswith('.txt')]
ID=int(sys.argv[1])
# 遍历文件列表
#for i, file in enumerate(files):
def main(i, file):
    # 构建源文件和目标文件的完整路径
    src_file = os.path.join(denovo_kmer_type_path, file)
    sv_file = os.path.join(unique_kmer_type_path, file)
    print(src_file,sv_file)
    # 检查目标文件是否存在，如果不存在则进行处理
    if not Path(sv_file).exists():
        print("Work on it!")
        # 使用pandas读取数据
        d = pd.read_csv(src_file, header=None, names=["kmer", "count"], sep=' ')
        print(len(d))

        # 初始化'other'列
        d['other'] = 0
        print("start!")

        # 获取除当前文件外的其他文件列表
        other_files = files[:i] + files[i+1:]

        # 遍历其他文件，进行左连接操作
        for j, other_file in enumerate(other_files):
            other_dat = pd.read_csv(os.path.join(denovo_kmer_type_path, other_file), header=None, sep=' ')
            # 重命名列以避免名称冲突
            other_dat.columns=['kmer','V2']
            # 进行左连接
           # print(other_dat.head(3))
            d = pd.merge(d, other_dat, on='kmer', how='left')
            # 填充NaN值为0
            d.fillna(0, inplace=True)
            # 更新'other'列
            d['other'] += d['V2']
            # 删除临时列
            d.drop('V2', axis=1, inplace=True)
            print(j)
#            print(d)
        # 计算*out*列
        d['out'] = d['other'] / (d['count'] + d['other'])

        # 过滤*out*小于0.01的行
        d = d[d['out'] < 0.01]

        # 将结果保存到文件
        d.to_csv(sv_file, sep='\t', index=False, header=False)
        print("YES!!!!!!")
        print(len(d))
    else:
        print("No need!")
main(ID,files[ID] )
