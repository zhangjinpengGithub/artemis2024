import sys,os
for i in range(1,1288):
	print(f"/dssg/home/xuxx/anaconda3/envs/frag/bin/Rscript x7_select_nonmask_kmers.r  {i}")
