import sys,os
for i in range(0,1287):
	print(f"python 06_tmp.py  {i}")
