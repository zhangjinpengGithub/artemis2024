import os,sys
import pandas as pd
import re

# 从命令行参数获取索引
i = int(sys.argv[1])

# 获取 unique_kmer_type 目录下所有以 .txt 结尾的文件
files = sorted([os.path.join("./test", f) for f in os.listdir("./test") if f.endswith(".txt")])

# 选择文件列表中的第 i 个文件
current_file = files[i]
fname='>'+current_file.split("/")[-1].replace(".txt","")+"_"
print(fname)
# 构建输出文件名，将目录路径替换，并更改文件扩展名
f2 = re.sub(r"^.*/test", "./kmers_non_masked", current_file)
f2 = re.sub(r"\.txt$", ".csv", f2)# 构建最终输出文件名，更改文件扩展名为 .fasta
sv = re.sub(r"^.*/test", "./final_kmers", current_file)
sv = re.sub(r"\.txt$", ".fasta", sv)
#######################f2 is kmers with no masked,It is the kmers of the no repetitive sequence region
# 检查输出文件是否已存在
if not os.path.exists(sv):
    print("Running the code here!")
    d = pd.read_csv(current_file, sep='\t', header=None,low_memory=False) 
    if(d.shape[0]<1):
        sys.exit(0)
    d.columns=['kmer','count','other','out']
    # 读取 mask 文件内容到 DataFrame
    test_dat = pd.read_csv(f2,low_memory=False)
    
    # 过滤 kmer，只保留在 test_dat 中存在的(reprt region)
    d = d[d['kmer'].isin(test_dat['kmer'])]
    
    # 确保这些 kmer 是唯一的，即它们在重复类型中的出现频率小于1%
    d=d.query("out==0")
    
    count_flag=1
   
    # 将所有记录合并为一个字符串，并写入到 FASTA 文件
    with open(sv, 'w') as fasta_file:
        for j in d['kmer']:
            fasta_file.write(fname+str(count_flag) + "\n")
            fasta_file.write(j + "\n")
            count_flag=count_flag+1
            if(count_flag%500==499):
                fasta_file.flush()
    print(i)
    print(sv)
