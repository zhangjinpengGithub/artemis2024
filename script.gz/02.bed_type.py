import os,sys
#bedtools getfasta  -fi chrm13.mod.fna -bed ./bed_type/$name -fo ./fasta_type/${sample}.fasta -name -fullHea
with open(sys.argv[1]) as f:
    for i in f:
        i=i.strip().split("/")[2]
        sample=i.split(".bed")[0]
    #    print(f" jellyfish count --mer-len 24 --size 10G --threads 4 --canonical --quality-start=32 --lower-count=1 --output ./denovo_kmer_type/{sample}.jellyfish ./fasta_type/{sample}.fasta")
        print(f"jellyfish dump --column ./denovo_kmer_type/{sample}.jellyfish > ./denovo_kmer_type/{sample}.txt")
