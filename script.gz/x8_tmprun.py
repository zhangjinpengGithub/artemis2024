import sys,os
for i in range(0,1287):
	print(f"python x8.py  {i}")
