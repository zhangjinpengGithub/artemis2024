import subprocess
import time
while(1):
    time.sleep(2)
    print("start sun")
    cmd="""bjobs -w |grep PEND|awk '{print " bmod -n 16 "$1}' |sh"""
    print(cmd)
    subprocess.call(cmd, shell=True)
