import os,sys
#bedtools getfasta  -fi chrm13.mod.fna -bed ./bed_type/$name -fo ./fasta_type/${sample}.fasta -name -fullHea
with open(sys.argv[1]) as f:
    for i in f:
        i=i.strip().split("/")[2]
        sample=i.split(".bed")[0]
        print(f"bedtools getfasta  -fi chrm13.mod.fna -bed ./bed_type/{i} -fo ./fasta_type/{sample}.fasta -name -fullHeader")
