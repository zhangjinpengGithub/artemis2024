bedtools getfasta  -fi chrm13.mod.fna -bed './bed_type/(GAATG)n#Satellite.bed' -fo './fasta_type/(GAATG)n#Satellite.fasta' -name -fullHeader
jellyfish count --mer-len 24 --size 10G --threads 4 --canonical --quality-start=32 --lower-count=1 --output './denovo_kmer_type/(GAATG)n#Satellite.jellyfish' './fasta_type/(GAATG)n#Satellite.fasta'
jellyfish dump --column './denovo_kmer_type/(GAATG)n#Satellite.jellyfish' > './denovo_kmer_type/(GAATG)n#Satellite.txt'
bedtools getfasta  -fi chrm13.mod.fna -bed './bed_type/tRNA-Leu-TTA(m)#tRNA.bed' -fo './fasta_type/tRNA-Leu-TTA(m)#tRNA.fasta' -name -fullHeader
jellyfish count --mer-len 24 --size 10G --threads 4 --canonical --quality-start=32 --lower-count=1 --output './denovo_kmer_type/tRNA-Leu-TTA(m)#tRNA.jellyfish' './fasta_type/tRNA-Leu-TTA(m)#tRNA.fasta'
jellyfish dump --column './denovo_kmer_type/tRNA-Leu-TTA(m)#tRNA.jellyfish' > './denovo_kmer_type/tRNA-Leu-TTA(m)#tRNA.txt'
bedtools getfasta  -fi chrm13.mod.fna -bed './bed_type/tRNA-Ser-TCA(m)#tRNA.bed' -fo './fasta_type/tRNA-Ser-TCA(m)#tRNA.fasta' -name -fullHeader
jellyfish count --mer-len 24 --size 10G --threads 4 --canonical --quality-start=32 --lower-count=1 --output './denovo_kmer_type/tRNA-Ser-TCA(m)#tRNA.jellyfish' './fasta_type/tRNA-Ser-TCA(m)#tRNA.fasta'
jellyfish dump --column './denovo_kmer_type/tRNA-Ser-TCA(m)#tRNA.jellyfish' > './denovo_kmer_type/tRNA-Ser-TCA(m)#tRNA.txt'
bedtools getfasta  -fi chrm13.mod.fna -bed './bed_type/tRNA-SeC(e)-TGA#tRNA.bed' -fo './fasta_type/tRNA-SeC(e)-TGA#tRNA.fasta' -name -fullHeader
jellyfish count --mer-len 24 --size 10G --threads 4 --canonical --quality-start=32 --lower-count=1 --output './denovo_kmer_type/tRNA-SeC(e)-TGA#tRNA.jellyfish' './fasta_type/tRNA-SeC(e)-TGA#tRNA.fasta'
jellyfish dump --column './denovo_kmer_type/tRNA-SeC(e)-TGA#tRNA.jellyfish' > './denovo_kmer_type/tRNA-SeC(e)-TGA#tRNA.txt'
bedtools getfasta  -fi chrm13.mod.fna -bed './bed_type/(CATTC)n#Satellite.bed' -fo './fasta_type/(CATTC)n#Satellite.fasta' -name -fullHeader
jellyfish count --mer-len 24 --size 10G --threads 4 --canonical --quality-start=32 --lower-count=1 --output './denovo_kmer_type/(CATTC)n#Satellite.jellyfish' './fasta_type/(CATTC)n#Satellite.fasta'
jellyfish dump --column './denovo_kmer_type/(CATTC)n#Satellite.jellyfish' > './denovo_kmer_type/(CATTC)n#Satellite.txt'
